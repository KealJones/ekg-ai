import type { ProgramBlueprint } from "./ir/blueprint.js";
import type { Type } from "./ir/types.js";
import { typeEquals } from "./ir/types.js";

export interface ProgramLibrary {
  put(program: ProgramBlueprint): void;
  get(id: string): ProgramBlueprint | undefined;
  all(): ProgramBlueprint[];
  compatible(inputs: Type[], output: Type): ProgramBlueprint[];
}

export class MemoryProgramLibrary implements ProgramLibrary {
  private readonly programs = new Map<string, ProgramBlueprint>();

  put(program: ProgramBlueprint): void {
    this.programs.set(program.id, structuredClone(program));
  }

  get(id: string): ProgramBlueprint | undefined {
    const p = this.programs.get(id);
    return p ? structuredClone(p) : undefined;
  }

  all(): ProgramBlueprint[] {
    return [...this.programs.values()].map(p => structuredClone(p));
  }

  compatible(inputs: Type[], output: Type): ProgramBlueprint[] {
    return this.all().filter(p =>
      p.inputs.length === inputs.length &&
      p.inputs.every((t, i) => typeEquals(t, inputs[i]!)) &&
      typeEquals(p.output, output)
    );
  }
}
