import type { Type } from "./types.js";

export type Value = boolean | number | string | Value[];

export type Expr =
  | { kind: "const"; value: Value; type: Type }
  | { kind: "input"; index: number; type: Type }
  | { kind: "call"; capabilityId: string; args: Expr[]; type: Type }
  | { kind: "program_call"; programId: string; args: Expr[]; type: Type };

export interface ProgramBlueprint {
  id: string;
  name?: string;
  inputs: Type[];
  output: Type;
  body: Expr;
  properties?: string[];
  provenance?: string[];
}

export function stableBlueprintJson(program: ProgramBlueprint): string {
  return JSON.stringify(program);
}
